import { View, Text } from 'react-native'
import React from 'react'
import Dashboard from '@/components/ui/dashboard'

export default function Page() {
  return (
      <Dashboard />
  )
}