import React from 'react'
import TeacherProfile from '@/components/ui/TeacherProfile'

export default function Profile() {
  return (
    <TeacherProfile />
  )
}