import { View, Text } from 'react-native'
import React from 'react'

const About = () => {
  return (
    <View>
      <Text>About</Text>
    </View>
  )
}

export default About